# Configurable banking-style eligibility rules for this academic project.
# These thresholds are examples, NOT official rules of any real bank.

def calculate_dti(applicant_income, coapplicant_income, loan_amount, loan_term_months, annual_interest_rate=10.0):
    """Estimate monthly EMI and return EMI as a percentage of monthly income."""
    monthly_income = max(applicant_income + coapplicant_income, 1.0)
    principal = loan_amount * 1000.0
    months = max(int(loan_term_months), 1)
    monthly_rate = annual_interest_rate / 1200.0
    if monthly_rate == 0:
        emi = principal / months
    else:
        emi = principal * monthly_rate * (1 + monthly_rate) ** months / ((1 + monthly_rate) ** months - 1)
    return (emi / monthly_income) * 100.0

def calculate_lti(applicant_income, coapplicant_income, loan_amount):
    """Return loan amount as a percentage of annual combined income."""
    annual_income = max((applicant_income + coapplicant_income) * 12.0, 1.0)
    return (loan_amount * 1000.0 / annual_income) * 100.0

def calculate_risk_score(ml_probability, credit_history, dti, lti, age, self_employed):
    """Create a transparent 0-100 application strength score."""
    score = ml_probability * 60.0
    score += 20.0 if credit_history == 1 else -20.0
    score += 10.0 if dti <= 35 else 4.0 if dti <= 50 else -8.0 if dti <= 60 else -18.0
    score += 5.0 if lti <= 300 else 1.0 if lti <= 500 else -8.0
    score += 5.0 if 25 <= age <= 55 else -2.0
    if self_employed == "Yes":
        score -= 1.0
    return max(0.0, min(100.0, score))

def evaluate_rules(values, ml_probability):
    """Run deterministic checks and return APPROVE, MANUAL REVIEW, or REJECT."""
    age = int(values["Age"])
    credit = float(values["Credit_History"])
    applicant_income = float(values["ApplicantIncome"])
    coapplicant_income = float(values["CoapplicantIncome"])
    loan_amount = float(values["LoanAmount"])
    loan_term = int(values["Loan_Amount_Term"])

    dti = calculate_dti(applicant_income, coapplicant_income, loan_amount, loan_term)
    lti = calculate_lti(applicant_income, coapplicant_income, loan_amount)

    rules = [
        ("Age requirement", 21 <= age <= 60, "critical", f"{age} years",
         "Applicant age must be between 21 and 60."),
        ("Credit history", credit == 1, "critical", "Good" if credit == 1 else "Poor",
         "Good credit history is required for automatic approval."),
        ("Minimum income", applicant_income + coapplicant_income >= 15000, "critical",
         f"₹{applicant_income + coapplicant_income:,.0f}/month",
         "Combined monthly income should be at least ₹15,000."),
        ("Debt-to-income ratio", dti <= 50, "warning", f"{dti:.1f}%",
         "Estimated DTI should normally be 50% or below."),
        ("Loan-to-income ratio", lti <= 500, "warning", f"{lti:.1f}%",
         "Loan amount should normally remain within 5x annual income."),
        ("Loan term", loan_term in {120, 180, 240, 300, 360}, "warning",
         f"{loan_term} months", "Loan term must be one of the supported terms."),
    ]

    critical_failures = [r for r in rules if not r[1] and r[2] == "critical"]
    warning_failures = [r for r in rules if not r[1] and r[2] == "warning"]

    risk_score = calculate_risk_score(
        ml_probability, credit, dti, lti, age, values["Self_Employed"]
    )

    if critical_failures:
        decision = "REJECT"
    elif ml_probability >= 0.70 and not warning_failures and risk_score >= 65:
        decision = "APPROVE"
    elif ml_probability >= 0.45 and risk_score >= 45:
        decision = "MANUAL REVIEW"
    else:
        decision = "REJECT"

    return {
        "decision": decision,
        "risk_score": round(risk_score, 2),
        "dti": round(dti, 2),
        "lti": round(lti, 2),
        "rules": rules,
        "critical_failures": critical_failures,
        "warning_failures": warning_failures,
    }
