from risk_rules import evaluate_rules

applicant = {
    "Age": 35, "Credit_History": 1.0,
    "ApplicantIncome": 60000, "CoapplicantIncome": 30000,
    "LoanAmount": 150, "Loan_Amount_Term": 360,
    "Self_Employed": "No",
}

result = evaluate_rules(applicant, 0.85)

print("Decision:", result["decision"])
print("Risk score:", result["risk_score"])
print("DTI:", result["dti"], "%")
print("LTI:", result["lti"], "%")
for rule in result["rules"]:
    print(rule[0], "PASS" if rule[1] else "FAIL", "-", rule[4])
