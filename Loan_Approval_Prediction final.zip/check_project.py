# Quick end-to-end project check.

from pathlib import Path
import pandas as pd

from utils import load_trained_package, predict_applicant

print("1. Checking dataset...")
df = pd.read_csv("data/loan_data.csv")
print(f"Dataset: {df.shape[0]} rows x {df.shape[1]} columns")

print("\n2. Checking saved model...")
load_trained_package()
print("Saved model package loaded successfully.")

print("\n3. Checking prediction pipeline...")
applicant = {
    "Gender": "Male",
    "Married": "Yes",
    "Dependents": "0",
    "Education": "Graduate",
    "Self_Employed": "No",
    "ApplicantIncome": 50000,
    "CoapplicantIncome": 0,
    "LoanAmount": 120,
    "Loan_Amount_Term": 360,
    "Credit_History": 1.0,
    "Property_Area": "Urban",
    "Age": 35,
    "Region": "South",
}

prediction, probability = predict_applicant(applicant)

print("Prediction:", prediction)
print("Approval probability:", f"{probability:.4f}")

print("\n4. Checking requested age range...")
assert 21 <= applicant["Age"] <= 60
print("Age range: 21-60")

print("\nPROJECT CHECK PASSED")
