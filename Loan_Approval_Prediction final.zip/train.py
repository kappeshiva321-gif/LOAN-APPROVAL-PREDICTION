# ============================================================
# LOAN APPROVAL PREDICTION - COMPLETE TRAINING PIPELINE
# Every important line is commented for learning.
# ============================================================

# Import json so evaluation results can be saved in a readable file.
import json

# Import os so folders can be created when they do not exist.
import os

# Import warnings so non-critical warning messages can be hidden.
import warnings

# Import numpy for numerical calculations.
import numpy as np

# Import pandas for reading and manipulating CSV data.
import pandas as pd

# Import joblib to save the trained machine-learning pipeline.
import joblib

# Import matplotlib for generating plots.
import matplotlib.pyplot as plt

# Import seaborn for attractive confusion-matrix visualization.
import seaborn as sns

# Import train_test_split to divide the dataset into training and testing data.
from sklearn.model_selection import train_test_split

# Import ColumnTransformer to apply different preprocessing to different column types.
from sklearn.compose import ColumnTransformer

# Import SimpleImputer to fill missing values.
from sklearn.impute import SimpleImputer

# Import OneHotEncoder to convert text categories into numerical columns.
from sklearn.preprocessing import OneHotEncoder, StandardScaler

# Import Pipeline so preprocessing and model steps stay together.
from sklearn.pipeline import Pipeline

# Import LogisticRegression as the meta-learner in the stacking ensemble.
from sklearn.linear_model import LogisticRegression

# Import RandomForestClassifier as one of the base learners.
from sklearn.ensemble import RandomForestClassifier, StackingClassifier

# Import evaluation metrics.
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
)

# Import SMOTEENN for hybrid class-imbalance handling.
from imblearn.combine import SMOTEENN

# Import XGBoost's classifier.
from xgboost import XGBClassifier

# Import LightGBM's classifier.
from lightgbm import LGBMClassifier

# Stop Python from displaying many warning messages during training.
warnings.filterwarnings("ignore")


# -----------------------------
# 1. Create output directories
# -----------------------------

# Create the models folder if it does not already exist.
os.makedirs("models", exist_ok=True)

# Create the reports folder if it does not already exist.
os.makedirs("reports", exist_ok=True)


# -----------------------------
# 2. Load the dataset
# -----------------------------

# Store the location of the CSV dataset.
DATA_PATH = "data/loan_data.csv"

# Read the CSV file into a pandas DataFrame.
df = pd.read_csv(DATA_PATH)

# Display the number of rows and columns so the user knows the dataset size.
print("Dataset shape:", df.shape)

# Display the first five records for a quick inspection.
print(df.head())


# -----------------------------
# 3. Basic data cleaning
# -----------------------------

# Remove Loan_ID because it is an identifier, not a useful predictive feature.
if "Loan_ID" in df.columns:
    df = df.drop(columns=["Loan_ID"])

# Remove rows where the target Loan_Status is missing.
df = df.dropna(subset=["Loan_Status"])

# Convert the target from Y/N into 1/0.
df["Loan_Status"] = df["Loan_Status"].map({"Y": 1, "N": 0})

# Check how many examples belong to each target class.
print("Class distribution:")
print(df["Loan_Status"].value_counts())


# -----------------------------
# 4. Separate X and y
# -----------------------------

# X contains the applicant features used by the machine-learning model.
X = df.drop(columns=["Loan_Status"])

# y contains the final target: 1 means approved and 0 means rejected.
y = df["Loan_Status"]


# -----------------------------
# 5. Train/test split
# -----------------------------

# Split the data so the model is trained on one part and evaluated on unseen data.
X_train, X_test, y_train, y_test = train_test_split(
    X,                         # Input features.
    y,                         # Target labels.
    test_size=0.20,            # Keep 20% of the data for final testing.
    random_state=42,           # Make the split reproducible.
    stratify=y                 # Preserve approximately the same class ratio.
)

# Print the sizes of the two datasets.
print("Training rows:", len(X_train))
print("Testing rows:", len(X_test))


# -----------------------------
# 6. Identify column types
# -----------------------------

# Select all text/categorical columns.
categorical_features = X_train.select_dtypes(include=["object"]).columns.tolist()

# Select all numerical columns.
numerical_features = X_train.select_dtypes(exclude=["object"]).columns.tolist()

# Print the selected columns so a beginner can see what will be encoded/scaled.
print("Categorical columns:", categorical_features)
print("Numerical columns:", numerical_features)


# -----------------------------
# 7. Build preprocessing
# -----------------------------

# Create a pipeline for numerical columns.
numeric_pipeline = Pipeline(
    steps=[
        # Fill missing numerical values using the median.
        ("imputer", SimpleImputer(strategy="median")),

        # Standardize numerical values to a comparable scale.
        ("scaler", StandardScaler()),
    ]
)

# Create a pipeline for categorical columns.
categorical_pipeline = Pipeline(
    steps=[
        # Fill missing categories using the most frequent category.
        ("imputer", SimpleImputer(strategy="most_frequent")),

        # Convert text categories into binary indicator columns.
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ]
)

# Combine the numerical and categorical preprocessing.
preprocessor = ColumnTransformer(
    transformers=[
        # Apply the numerical pipeline only to numerical columns.
        ("num", numeric_pipeline, numerical_features),

        # Apply the categorical pipeline only to categorical columns.
        ("cat", categorical_pipeline, categorical_features),
    ]
)


# -----------------------------
# 8. Transform training data
# -----------------------------

# Fit the preprocessing rules using training data and transform the training data.
X_train_encoded = preprocessor.fit_transform(X_train)

# Transform the test data using the same rules learned from training data.
X_test_encoded = preprocessor.transform(X_test)

# Convert sparse matrices to dense arrays if necessary.
if hasattr(X_train_encoded, "toarray"):
    X_train_encoded = X_train_encoded.toarray()

# Convert the test matrix to dense format if necessary.
if hasattr(X_test_encoded, "toarray"):
    X_test_encoded = X_test_encoded.toarray()

# Print the transformed feature count.
print("Encoded feature count:", X_train_encoded.shape[1])


# -----------------------------
# 9. Apply SMOTE-ENN
# -----------------------------

# Create the SMOTE-ENN object.
smote_enn = SMOTEENN(random_state=42)

# Oversample the minority class and remove noisy examples.
X_resampled, y_resampled = smote_enn.fit_resample(
    X_train_encoded,
    y_train
)

# Print the class distribution after resampling.
print("Class distribution after SMOTE-ENN:")
print(pd.Series(y_resampled).value_counts())


# -----------------------------
# 10. Create base learners
# -----------------------------

# Create the Random Forest classifier.
rf = RandomForestClassifier(
    n_estimators=200,           # Use 200 decision trees.
    max_depth=None,             # Allow trees to grow until stopping criteria.
    random_state=42,            # Make training reproducible.
    class_weight="balanced",    # Give additional weight to the minority class.
)

# Create the XGBoost classifier.
xgb = XGBClassifier(
    n_estimators=200,           # Number of boosting rounds.
    max_depth=5,                # Maximum tree depth.
    learning_rate=0.05,         # Step size used by boosting.
    subsample=0.9,              # Use 90% of rows for each boosting round.
    colsample_bytree=0.9,       # Use 90% of features for each tree.
    eval_metric="logloss",      # Classification loss metric.
    random_state=42,            # Reproducible results.
)

# Create the LightGBM classifier.
lgbm = LGBMClassifier(
    n_estimators=200,           # Number of boosting trees.
    learning_rate=0.05,         # Learning rate.
    num_leaves=31,              # Maximum leaves in each tree.
    random_state=42,            # Reproducible results.
    verbosity=-1,               # Reduce console output.
)


# -----------------------------
# 11. Build stacked ensemble
# -----------------------------

# Put the three base learners into a list.
base_models = [
    ("random_forest", rf),
    ("xgboost", xgb),
    ("lightgbm", lgbm),
]

# Create the stacked ensemble.
stacked_model = StackingClassifier(
    estimators=base_models,                  # Base models produce intermediate predictions.
    final_estimator=LogisticRegression(max_iter=1000),  # Meta-learner combines them.
    stack_method="predict_proba",            # Use probabilities as the stacking features.
    passthrough=False,                       # Do not directly pass original features to meta-learner.
)


# -----------------------------
# 12. Train the ensemble
# -----------------------------

# Start training the complete stacked ensemble on the resampled data.
print("Training ensemble...")

# Fit the three base learners and the logistic meta-learner.
stacked_model.fit(X_resampled, y_resampled)

# Inform the user that training has finished.
print("Training completed.")


# -----------------------------
# 13. Predict on test data
# -----------------------------

# Predict whether each unseen applicant is approved or rejected.
y_pred = stacked_model.predict(X_test_encoded)

# Predict the probability of approval.
y_prob = stacked_model.predict_proba(X_test_encoded)[:, 1]


# -----------------------------
# 14. Calculate evaluation metrics
# -----------------------------

# Calculate the percentage of predictions that are correct.
accuracy = accuracy_score(y_test, y_pred)

# Calculate precision: among predicted approvals, how many are correct.
precision = precision_score(y_test, y_pred, zero_division=0)

# Calculate recall: among actual approvals, how many were found.
recall = recall_score(y_test, y_pred, zero_division=0)

# Calculate F1 score, balancing precision and recall.
f1 = f1_score(y_test, y_pred, zero_division=0)

# Calculate ROC-AUC using predicted approval probabilities.
auc = roc_auc_score(y_test, y_prob)

# Store all metrics in one dictionary.
metrics = {
    "accuracy": round(float(accuracy), 4),
    "precision": round(float(precision), 4),
    "recall": round(float(recall), 4),
    "f1_score": round(float(f1), 4),
    "roc_auc": round(float(auc), 4),
}

# Print the metrics.
print(json.dumps(metrics, indent=2))


# -----------------------------
# 15. Save evaluation metrics
# -----------------------------

# Open the metrics JSON file for writing.
with open("reports/model_metrics.json", "w") as file:

    # Write the metrics dictionary in readable JSON format.
    json.dump(metrics, file, indent=4)


# -----------------------------
# 16. Confusion matrix
# -----------------------------

# Calculate the four confusion-matrix components.
cm = confusion_matrix(y_test, y_pred)

# Create a new figure.
plt.figure(figsize=(6, 5))

# Draw the confusion matrix as a heatmap.
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=["Rejected", "Approved"],
    yticklabels=["Rejected", "Approved"],
)

# Add the horizontal-axis title.
plt.xlabel("Predicted")

# Add the vertical-axis title.
plt.ylabel("Actual")

# Add the chart title.
plt.title("Loan Approval Confusion Matrix")

# Adjust the layout.
plt.tight_layout()

# Save the chart to the reports folder.
plt.savefig("reports/confusion_matrix.png")

# Close the figure so memory is released.
plt.close()


# -----------------------------
# 17. ROC curve
# -----------------------------

# Calculate false-positive rate and true-positive rate.
fpr, tpr, _ = roc_curve(y_test, y_prob)

# Create a new figure.
plt.figure(figsize=(7, 5))

# Plot the ROC curve.
plt.plot(fpr, tpr, label=f"Stacked Ensemble AUC = {auc:.3f}")

# Plot the random-guess baseline.
plt.plot([0, 1], [0, 1], linestyle="--")

# Add the horizontal-axis label.
plt.xlabel("False Positive Rate")

# Add the vertical-axis label.
plt.ylabel("True Positive Rate")

# Add the title.
plt.title("ROC Curve")

# Show the legend.
plt.legend()

# Adjust the layout.
plt.tight_layout()

# Save the ROC figure.
plt.savefig("reports/roc_curve.png")

# Close the figure.
plt.close()


# -----------------------------
# 18. Fairness audit
# -----------------------------

# Define a helper function for approval-rate parity.
def approval_rate_difference(group_column, X_original, predictions):
    # Create a copy so we can safely attach prediction results.
    temp = X_original.copy()

    # Add the model's predictions to the copied DataFrame.
    temp["prediction"] = predictions

    # Find all unique groups in the selected protected attribute.
    groups = temp[group_column].dropna().unique()

    # Create an empty dictionary to hold each group's approval rate.
    rates = {}

    # Calculate the approval rate for every group.
    for group in groups:

        # Select only rows belonging to the current group.
        group_rows = temp[temp[group_column] == group]

        # Calculate the percentage predicted as approved.
        rates[str(group)] = float(group_rows["prediction"].mean())

    # If there are fewer than two groups, a difference cannot be calculated.
    if len(rates) < 2:
        return rates, 0.0

    # Calculate the difference between the highest and lowest approval rate.
    difference = max(rates.values()) - min(rates.values())

    # Return group rates and the maximum disparity.
    return rates, float(difference)


# Store fairness results in this dictionary.
fairness_report = {}

# Audit gender because it is a protected attribute in the proposed research direction.
if "Gender" in X_test.columns:
    rates, diff = approval_rate_difference("Gender", X_test, y_pred)
    fairness_report["Gender"] = {
        "approval_rates": rates,
        "max_rate_difference": diff,
    }

# Audit region because the research direction also mentions region.
if "Region" in X_test.columns:
    rates, diff = approval_rate_difference("Region", X_test, y_pred)
    fairness_report["Region"] = {
        "approval_rates": rates,
        "max_rate_difference": diff,
    }

# Audit age groups by creating three simple age bands.
if "Age" in X_test.columns:
    age_copy = X_test.copy()

    # Convert age into three groups for an easy demonstration audit.
    age_copy["Age_Group"] = pd.cut(
        age_copy["Age"],
        bins=[0, 30, 45, 100],
        labels=["Young", "Middle", "Older"],
    )

    # Calculate group approval rates for age groups.
    rates, diff = approval_rate_difference("Age_Group", age_copy, y_pred)

    # Save the age fairness result.
    fairness_report["Age_Group"] = {
        "approval_rates": rates,
        "max_rate_difference": diff,
    }

# Save the fairness audit to JSON.
with open("reports/fairness_report.json", "w") as file:
    json.dump(fairness_report, file, indent=4)


# -----------------------------
# 19. Explainability
# -----------------------------

# Try SHAP because it is an optional explainability package.
try:

    # Import SHAP only when it is installed.
    import shap

    # Select a manageable sample of test data for explanation.
    explanation_data = X_test_encoded[:100]

    # Create a SHAP explainer around the ensemble's probability function.
    explainer = shap.Explainer(
        stacked_model.predict_proba,
        explanation_data,
    )

    # Calculate SHAP values.
    shap_values = explainer(explanation_data)

    # Create a SHAP summary plot.
    plt.figure()

    # Draw the global importance summary.
    shap.plots.beeswarm(shap_values[:, :, 1], show=False)

    # Adjust the plot layout.
    plt.tight_layout()

    # Save the SHAP figure.
    plt.savefig("reports/shap_summary.png", bbox_inches="tight")

    # Close the plot.
    plt.close()

    # Inform the user.
    print("SHAP explanation saved.")

# Catch SHAP-specific errors without stopping the complete training pipeline.
except Exception as shap_error:

    # Save the reason so the user knows why SHAP was skipped.
    with open("reports/shap_status.txt", "w") as file:
        file.write(str(shap_error))

    # Print a friendly message.
    print("SHAP explanation skipped:", shap_error)


# -----------------------------
# 20. Save the complete model
# -----------------------------

# Store both preprocessing and model together.
complete_pipeline = {
    "preprocessor": preprocessor,
    "model": stacked_model,
    "feature_columns": list(X.columns),
}

# Save the dictionary so the prediction application can reuse the exact preprocessing.
joblib.dump(complete_pipeline, "models/loan_model.joblib")

# Tell the user where the model was saved.
print("Saved model to models/loan_model.joblib")

# Print a final success message.
print("Loan approval project training finished successfully.")
