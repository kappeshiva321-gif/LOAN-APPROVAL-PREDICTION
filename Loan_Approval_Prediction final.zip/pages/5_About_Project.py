import streamlit as st
st.title("ℹ️ About Project")
st.write("Loan Approval Prediction using Random Forest, XGBoost, LightGBM, stacking, SMOTE-ENN, explainability and fairness auditing.")
st.write("Age range configured for this project: 21–60 years.")
st.write("Run python train.py before using prediction and analytics pages.")