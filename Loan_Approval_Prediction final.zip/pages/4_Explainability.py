import json; from pathlib import Path; import streamlit as st
st.title("🔍 Explainability & Fairness")
if Path("reports/shap_summary.png").exists(): st.image("reports/shap_summary.png",use_container_width=True)
else: st.info("Run python train.py to generate SHAP output.")
p=Path("reports/fairness_report.json")
if p.exists(): st.json(json.loads(p.read_text()))
else: st.info("Fairness report not found.")