import json; from pathlib import Path; import streamlit as st
st.title("📊 Model Performance")
p=Path("reports/model_metrics.json")
if not p.exists(): st.error("Run python train.py first."); st.stop()
m=json.loads(p.read_text()); cols=st.columns(5)
for col,(label,key) in zip(cols,[("Accuracy","accuracy"),("Precision","precision"),("Recall","recall"),("F1","f1_score"),("ROC-AUC","roc_auc")]): col.metric(label,f"{m[key]*100:.2f}%")
for f,title in [("reports/confusion_matrix.png","Confusion Matrix"),("reports/roc_curve.png","ROC Curve")]:
 st.subheader(title); st.image(f) if Path(f).exists() else st.info("Run training first.")