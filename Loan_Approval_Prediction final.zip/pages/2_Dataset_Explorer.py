# ============================================================
# DATASET EXPLORER
# ============================================================

from pathlib import Path
import pandas as pd
import streamlit as st

st.title("📁 Dataset Explorer")

st.write(
    "This page lets you inspect the project's training dataset and "
    "the three additional datasets supplied for this project."
)

datasets = {
    "Project Training Dataset": Path("data/loan_data.csv"),
    "Dataset 1 - Original Loan Dataset": Path("data/external_datasets/dataset1.csv"),
    "Dataset 2 - Loan Dataset": Path("data/external_datasets/dataset2.csv"),
    "Dataset 3 - Extended Loan Risk Dataset": Path("data/external_datasets/dataset3.csv"),
}

selected = st.selectbox("Select a dataset", list(datasets.keys()))
path = datasets[selected]

if not path.exists():
    st.error(f"Dataset file not found: {path}")
    st.stop()

df = pd.read_csv(path)

st.subheader("Dataset Overview")

c1, c2, c3 = st.columns(3)
c1.metric("Rows", f"{df.shape[0]:,}")
c2.metric("Columns", df.shape[1])
c3.metric("Missing Values", int(df.isna().sum().sum()))

st.subheader("Columns")
st.write(list(df.columns))

st.subheader("Preview")
st.dataframe(df.head(20), use_container_width=True)

st.subheader("Data Types")
st.dataframe(
    pd.DataFrame({
        "Column": df.columns,
        "Data Type": [str(x) for x in df.dtypes],
        "Missing Values": [int(x) for x in df.isna().sum()],
        "Unique Values": [int(x) for x in df.nunique()],
    }),
    use_container_width=True,
)

st.subheader("Numerical Summary")
st.dataframe(df.describe(include="all").transpose(), use_container_width=True)

# Identify a likely loan-status column for a simple target distribution chart.
target = None
for candidate in ["Loan_Status", "loan_status"]:
    if candidate in df.columns:
        target = candidate
        break

if target:
    st.subheader("Loan Status Distribution")
    st.bar_chart(df[target].value_counts())

st.info(
    "The additional datasets are kept separately because their schemas are "
    "not identical. This avoids silently mixing incompatible features."
)
