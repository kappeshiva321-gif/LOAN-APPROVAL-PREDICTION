import joblib,pandas as pd,streamlit as st
st.title("🔮 Loan Prediction")
try:
 p=joblib.load("models/loan_model.joblib"); prep=p["preprocessor"]; model=p["model"]
except FileNotFoundError:
 st.error("Run python train.py first."); st.stop()
c1,c2=st.columns(2)
with c1:
 gender=st.selectbox("Gender",["Male","Female"]); married=st.selectbox("Married",["Yes","No"]); dependents=st.selectbox("Dependents",["0","1","2","3+"]); education=st.selectbox("Education",["Graduate","Not Graduate"]); self_emp=st.selectbox("Self Employed",["Yes","No"]); age=st.number_input("Age",21,60,35,1); region=st.selectbox("Region",["North","South","East","West"])
with c2:
 income=st.number_input("Applicant Income",0,1000000,5000); co=st.number_input("Coapplicant Income",0,1000000,1000); loan=st.number_input("Loan Amount",1,1000000,120); term=st.selectbox("Loan Amount Term",[120,180,240,300,360],index=4); credit=st.selectbox("Credit History",[1.0,0.0]); prop=st.selectbox("Property Area",["Urban","Semiurban","Rural"])
if st.button("Predict Loan Approval",type="primary"):
 d=pd.DataFrame([{"Gender":gender,"Married":married,"Dependents":dependents,"Education":education,"Self_Employed":self_emp,"ApplicantIncome":income,"CoapplicantIncome":co,"LoanAmount":loan,"Loan_Amount_Term":term,"Credit_History":credit,"Property_Area":prop,"Age":age,"Region":region}]); x=prep.transform(d); x=x.toarray() if hasattr(x,"toarray") else x; pred=model.predict(x)[0]; prob=model.predict_proba(x)[0][1]; (st.success if pred else st.error)("Loan Prediction: APPROVED" if pred else "Loan Prediction: REJECTED"); st.metric("Approval Probability",f"{prob*100:.2f}%")