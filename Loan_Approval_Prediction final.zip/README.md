# Loan Approval Prediction Using Machine Learning
## Fully commented Python reference project

This project follows the uploaded research direction:
- structured applicant data
- preprocessing and feature engineering
- SMOTE-ENN for class imbalance
- Random Forest + XGBoost + LightGBM
- Logistic Regression meta-learner
- SHAP/LIME explainability
- fairness audit
- loan approval prediction
- Streamlit user interface

The uploaded document describes the proposed novelty as a unified ensemble with explainability,
fairness auditing, hybrid SMOTE-ENN resampling, alternative data fusion, and validation across
multiple public datasets. This implementation provides a practical academic prototype of the
core pipeline. It does not claim to reproduce the published papers or a regulated lending system.

## 1. Install

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS:
```bash
source venv/bin/activate
```

Then:
```bash
pip install -r requirements.txt
```

## 2. Train

```bash
python train.py
```

The script creates:
- models/loan_model.joblib
- reports/model_metrics.json
- reports/confusion_matrix.png
- reports/roc_curve.png
- reports/fairness_report.json
- reports/shap_summary.png when SHAP is available

## 3. Predict from command line

```bash
python predict.py
```

## 4. Run the web application

```bash
streamlit run app.py
```

Then open the local Streamlit address shown in the terminal.

## 5. Important dataset note

`data/loan_data.csv` is a small synthetic demonstration dataset so that the project can run
immediately. It is NOT a real bank dataset and must not be used for actual lending decisions.

For research evaluation, replace it with a public dataset such as the Loan Prediction Dataset,
LendingClub Loan Data, Home Credit Default Risk, or German Credit Data discussed in the uploaded
document. The uploaded document lists those datasets on page 4.

## Project structure

Loan_Approval_Prediction_Python_Explained/
|
|-- app.py                  # Streamlit interface
|-- train.py                # Complete training pipeline
|-- predict.py              # Command-line prediction
|-- utils.py                # Reusable preprocessing/prediction functions
|-- requirements.txt
|-- README.md
|
|-- data/
|   `-- loan_data.csv       # synthetic demo data
|
|-- models/
|   `-- loan_model.joblib   # created after training
|
`-- reports/
    |-- model_metrics.json
    |-- fairness_report.json
    |-- confusion_matrix.png
    `-- roc_curve.png

Every important Python line is commented so a beginner can study the code.


## Additional datasets

Three additional datasets supplied for the project are included in:

```text
data/external_datasets/
├── dataset1.csv
├── dataset2.csv
└── dataset3.csv
```

Use **Dataset Explorer** from the Streamlit sidebar to inspect them.

The main trained model intentionally continues to use `data/loan_data.csv`
because the additional datasets have different schemas. Dataset 3, in
particular, contains a different set of loan-risk features. The datasets are
therefore included for exploration and future model experiments rather than
being incorrectly merged.
