# How to study this project line by line

## train.py

Read in this order:

1. Imports
   - `pandas`: tables/data
   - `numpy`: numbers
   - `joblib`: save/load models
   - `sklearn`: preprocessing, splitting, metrics, stacking
   - `SMOTEENN`: class imbalance
   - `XGBClassifier`: XGBoost
   - `LGBMClassifier`: LightGBM

2. Data loading
   `pd.read_csv(...)`
   loads the CSV into memory.

3. Cleaning
   - remove ID
   - remove missing target rows
   - convert Y/N into 1/0

4. X and y
   - X = input features
   - y = target

5. Train/test split
   - 80% training
   - 20% testing
   - `stratify=y` keeps class proportions similar.

6. Preprocessing
   - numerical columns: median imputation + scaling
   - categorical columns: most-frequent imputation + one-hot encoding

7. SMOTE-ENN
   - SMOTE creates minority-class samples.
   - ENN removes some noisy examples.

8. Base models
   - Random Forest
   - XGBoost
   - LightGBM

9. Stacking
   Base-model probabilities become inputs to Logistic Regression.

10. Evaluation
   - Accuracy: overall correct predictions.
   - Precision: correctness of predicted approvals.
   - Recall: how many actual approvals were found.
   - F1: balance of precision and recall.
   - ROC-AUC: ranking quality across thresholds.

11. Fairness
   Approval-rate differences are calculated across Gender, Region and age groups.
   This is an audit indicator, NOT proof that a model is fair.

12. SHAP
   Attempts to generate feature-importance explanations.

13. Saving
   `joblib.dump(...)` stores preprocessing + model together.

## app.py

1. Streamlit creates the web page.
2. User enters applicant details.
3. Details become a one-row DataFrame.
4. The saved preprocessing is reused.
5. The saved model predicts approval.
6. Probability is displayed.

## predict.py

This is the smallest example for command-line prediction.

## Why the model is saved together with preprocessing

If training converts categories into encoded columns and scales numbers, prediction must
perform the exact same transformations. Saving both objects prevents the application from
using different preprocessing rules at prediction time.

## What to replace for your final academic project

Replace:
`data/loan_data.csv`

with a real public dataset and update the feature-column handling if its column names differ.

The uploaded document specifically lists:
- Loan Prediction Dataset
- LendingClub Loan Data
- Home Credit Default Risk
- German Credit Data

Use the dataset appropriate to your research scope and cite its source in your report.
