# Shared prediction functions used by app.py and predict.py.

from pathlib import Path
import joblib
import pandas as pd


def load_trained_package(model_path="models/loan_model.joblib"):
    """Load the saved preprocessing object and trained model."""
    path = Path(model_path)

    if not path.exists():
        raise FileNotFoundError(
            f"Model not found at {path}. Run `python train.py` first."
        )

    package = joblib.load(path)

    if "preprocessor" not in package or "model" not in package:
        raise ValueError(
            "The saved model package is missing the preprocessor or model."
        )

    return package


def predict_applicant(values, model_path="models/loan_model.joblib"):
    """Apply the training preprocessing and return prediction/probability."""
    package = load_trained_package(model_path)

    input_df = pd.DataFrame([values])

    encoded = package["preprocessor"].transform(input_df)

    if hasattr(encoded, "toarray"):
        encoded = encoded.toarray()

    prediction = int(package["model"].predict(encoded)[0])
    probability = float(package["model"].predict_proba(encoded)[0][1])

    return prediction, probability
