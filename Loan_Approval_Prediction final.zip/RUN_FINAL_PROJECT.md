# Advanced Loan Approval Project - Run Instructions

conda activate loan_project

cd C:\Users\nagul\Downloads\Loan_Approval_Bank_Style_Advanced_Final

pip install -r requirements.txt

python train.py

python check_project.py

python test_rules.py

streamlit run app.py

Open http://localhost:8501

The main page now combines ML prediction with configurable eligibility rules,
DTI/LTI affordability indicators, a risk score and APPROVE/MANUAL REVIEW/REJECT routing.

Age is restricted to 21–60.

IMPORTANT: These are academic banking-style rules, not official rules of any bank.
