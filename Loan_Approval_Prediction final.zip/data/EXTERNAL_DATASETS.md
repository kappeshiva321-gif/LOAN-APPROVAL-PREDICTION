# Additional Loan Datasets

The project now includes the three datasets supplied with the project.

## Dataset 1 — `dataset1.csv`

- Rows: 614
- Columns: 13
- Target: `loan_status`
- Main fields: gender, married, dependents, education, self_employed,
  applicantincome, coapplicantincome, loanamount, loan_amount_term,
  credit_history, property_area, loan_status.

## Dataset 2 — `dataset2.csv`

- Rows: 381
- Columns: 13
- Target: `Loan_Status`
- It uses essentially the same loan-application schema as Dataset 1,
  but with different capitalization and column names.

## Dataset 3 — `dataset3.csv`

- Rows: 45,000
- Columns: 14
- Target: `loan_status`
- It is a richer loan-risk dataset containing fields such as:
  `person_age`, `person_income`, `person_education`,
  `person_home_ownership`, `loan_amnt`, `loan_int_rate`,
  `loan_percent_income`, `credit_score`,
  `previous_loan_defaults_on_file`, and `loan_status`.

## Important

These datasets have different schemas. Therefore, they are stored separately
rather than incorrectly concatenating unrelated columns.

The existing website/model continues to use the project's validated
`data/loan_data.csv` training schema. The three supplied datasets are available
for dataset exploration, comparison, future experiments, and academic analysis.

Dataset 1 and Dataset 2 are compatible in concept, but their column names and
capitalization differ. Dataset 3 is a different feature schema and should not
be merged directly with Dataset 1/2 without a deliberate feature-mapping
strategy.
