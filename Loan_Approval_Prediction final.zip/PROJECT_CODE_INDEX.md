# Complete Python Code Index

This package now contains the complete Python implementation, including the original
explained project and the advanced banking-style prototype features.

| Python file | Purpose |
|---|---|
| `train.py` | Full ML training, preprocessing, SMOTE-ENN, RF/XGBoost/LightGBM stacking, evaluation, SHAP/fairness outputs |
| `app.py` | Main Streamlit loan eligibility application |
| `predict.py` | Command-line prediction example |
| `utils.py` | Shared model loading and prediction helpers |
| `risk_rules.py` | Configurable age, income, credit, DTI/LTI and risk-score rules |
| `compare_datasets.py` | Compare the included datasets |
| `check_project.py` | Validate project files and configuration |
| `test_rules.py` | Test the deterministic rule engine |
| `run_project.py` | Beginner-friendly one-command project runner |
| `pages/1_Loan_Prediction.py` | Multi-page prediction screen |
| `pages/2_Dataset_Explorer.py` | Dataset exploration screen |
| `pages/3_Model_Performance.py` | Model metric/report screen |
| `pages/4_Explainability.py` | Explainability screen |
| `pages/5_Advanced_Features.py` | Advanced/future banking-style features |
| `pages/5_About_Project.py` | Project/about screen |

## Important limitation

The advanced rules are educational examples, not official policies of any real bank.
Actual lending systems require institution-specific policy, verified financial and
credit data, fraud controls, regulatory compliance, security, audit logging, model
governance and human oversight.

## Main commands

```bash
python run_project.py
```

or, step by step:

```bash
python train.py
python test_rules.py
python predict.py
streamlit run app.py
```
