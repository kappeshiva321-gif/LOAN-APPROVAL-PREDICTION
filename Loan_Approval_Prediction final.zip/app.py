# ============================================================
# MODERN LOAN ELIGIBILITY CHECKER
# ============================================================

import time
from pathlib import Path

import pandas as pd
import streamlit as st

from utils import predict_applicant
from risk_rules import evaluate_rules

# Configure the Streamlit page.
st.set_page_config(
    page_title="Loan Eligibility AI",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# Custom CSS for a clean portfolio-style interface.
st.markdown("""
<style>
.stApp { background:#f7faff; }
.block-container { max-width:1200px; padding-top:1.5rem; }
.hero {
    background:linear-gradient(135deg,#0b2a4a,#123f68,#176b72);
    padding:3rem;
    border-radius:24px;
    color:white;
    margin-bottom:1.5rem;
}
.hero h1 { color:white; font-size:3rem; margin-bottom:.7rem; }
.hero p { color:#e7f2fb; font-size:1.1rem; max-width:780px; }
.section-title {
    color:#0b2a4a;
    font-size:1.65rem;
    font-weight:750;
    margin:1.4rem 0 .8rem;
}
.result-approved {
    background:#ecfdf3;
    border:1px solid #b7ebca;
    border-radius:20px;
    padding:1.5rem;
}
.result-rejected {
    background:#fff7ed;
    border:1px solid #fed7aa;
    border-radius:20px;
    padding:1.5rem;
}
</style>
""", unsafe_allow_html=True)

# ---------------- HERO SECTION ----------------
st.markdown("""
<div class="hero">
    <h1>Instant AI-Powered Loan Eligibility Checker</h1>
    <p>
        Enter your personal, financial and loan information to receive
        an ML-based eligibility estimate and probability score.
    </p>
</div>
""", unsafe_allow_html=True)

st.markdown(
    '<div class="section-title">Prediction Workspace</div>',
    unsafe_allow_html=True
)

# ---------------- INPUT WORKSPACE ----------------
left, right = st.columns([1.35, 1], gap="large")

with left:
    # Personal and demographic card.
    st.subheader("👤 Personal & Demographic Data")

    c1, c2 = st.columns(2)

    with c1:
        gender = st.selectbox("Gender", ["Male", "Female"])
        marital_status = st.selectbox(
            "Marital Status",
            ["Married", "Unmarried"],
        )
        dependents = st.selectbox(
            "Dependents",
            ["0", "1", "2", "3+"],
        )

    with c2:
        education = st.radio(
            "Education",
            ["Graduate", "Under-Graduate"],
            horizontal=True,
        )

        # User requested maximum age of 60.
        age = st.number_input(
            "Age",
            min_value=21,
            max_value=60,
            value=35,
            step=1,
            help="This project accepts applicants aged 21 to 60.",
        )

        property_area = st.selectbox(
            "Property Area",
            ["Urban", "Semi-Urban", "Rural"],
        )

    # Financial and employment card.
    st.subheader("💼 Financial & Employment Data")

    c1, c2 = st.columns(2)

    with c1:
        self_employed = st.radio(
            "Self-Employed",
            ["Yes", "No"],
            horizontal=True,
        )

        applicant_income = st.number_input(
            "Applicant Income (₹ / month)",
            min_value=0,
            value=50000,
            step=1000,
        )

    with c2:
        has_coapplicant = st.toggle(
            "Has Co-applicant",
            value=True,
        )

        if has_coapplicant:
            coapplicant_income = st.number_input(
                "Co-applicant Income (₹ / month)",
                min_value=0,
                value=0,
                step=1000,
            )
        else:
            coapplicant_income = 0
            st.caption("Co-applicant income disabled.")

    # Loan and credit card.
    st.subheader("🏦 Loan Specifics & Credit History")

    c1, c2 = st.columns(2)

    with c1:
        loan_amount = st.number_input(
            "Loan Amount (₹ thousands)",
            min_value=1,
            value=120,
            step=5,
        )

        loan_term = st.selectbox(
            "Loan Amount Term (months)",
            [120, 180, 240, 300, 360],
            index=4,
        )

    with c2:
        credit_history = st.radio(
            "Credit History",
            [1.0, 0.0],
            format_func=lambda x:
                "Good Credit (1)" if x == 1.0 else "Poor Credit (0)",
            horizontal=True,
        )

        st.caption(
            "Credit history is typically an important feature in loan datasets."
        )

    predict_clicked = st.button(
        "🤖 Predict Loan Eligibility",
        type="primary",
        use_container_width=True,
    )

# Store the rule-engine result only after a successful prediction.\nadvanced = None

with right:
    # Result panel is empty until prediction is requested.
    st.subheader("📌 Eligibility Result")

    if not predict_clicked:
        st.info(
            "Your result will appear here after you click "
            "**Predict Loan Eligibility**."
        )

    else:
        if not Path("models/loan_model.joblib").exists():
            st.error(
                "The trained model is not available. "
                "Run `python train.py` first."
            )
        else:
            # Convert UI values to the exact column names used during training.
            applicant = {
                "Gender": gender,
                "Married": (
                    "Yes" if marital_status == "Married" else "No"
                ),
                "Dependents": dependents,
                "Education": (
                    "Graduate"
                    if education == "Graduate"
                    else "Not Graduate"
                ),
                "Self_Employed": self_employed,
                "ApplicantIncome": applicant_income,
                "CoapplicantIncome": coapplicant_income,
                "LoanAmount": loan_amount,
                "Loan_Amount_Term": loan_term,
                "Credit_History": credit_history,
                "Property_Area": property_area,
                "Age": age,
                "Region": "South",
            }

            try:
                # Small spinner provides visible processing feedback.
                with st.spinner("Analyzing your application..."):
                    time.sleep(1)
                    prediction, probability = predict_applicant(applicant)
                advanced = evaluate_rules(applicant, probability)

                # Read the final decision produced by the rule engine.
                decision = advanced["decision"]

                # APPROVE means the ML score and all critical checks are strong enough.
                if decision == "APPROVE":
                    st.markdown(
                        f"""
                        <div class="result-approved">
                            <h2>✅ Likely Eligible</h2>
                            <p>
                                The application passed the configured automatic-
                                approval checks in this academic prototype.
                            </p>
                            <h3>
                                Approval Probability:
                                {probability * 100:.2f}%
                            </h3>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                # MANUAL REVIEW means the application is not an automatic approval
                # but is strong enough to be reviewed by a human decision-maker.
                elif decision == "MANUAL REVIEW":
                    st.warning(
                        f"🟡 Manual Review Recommended — "
                        f"ML approval probability: {probability * 100:.2f}%"
                    )
                    st.write(
                        "The application is in the configured review band. "
                        "A real lender would verify income, credit, documents, "
                        "fraud signals and other policy requirements before deciding."
                    )

                # REJECT means one or more critical rules failed or the overall
                # risk score is below the configured approval/review bands.
                else:
                    st.markdown(
                        f"""
                        <div class="result-rejected">
                            <h2>❌ Not Eligible Under Current Rules</h2>
                            <p>
                                The application did not satisfy the configured
                                automatic eligibility conditions.
                            </p>
                            <h3>
                                Approval Probability:
                                {probability * 100:.2f}%
                            </h3>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                    st.info(
                        "Possible improvement areas: maintain good credit "
                        "history, consider a lower loan amount, or strengthen "
                        "documented income."
                    )

                st.caption(
                    "This is an academic ML estimate and configurable rule-engine result, "
                    "not a bank guarantee or an actual lending decision."
                )

            except Exception as error:
                st.error("Prediction could not be completed.")
                st.exception(error)


# ---------------- ADVANCED BANK-STYLE RISK AUDIT ----------------
st.markdown('<div class="section-title">Bank-Style Risk & Eligibility Audit</div>',
            unsafe_allow_html=True)

if predict_clicked and "advanced" in locals() and advanced is not None:
    m1, m2, m3 = st.columns(3)
    m1.metric("Risk Score", f"{advanced['risk_score']:.1f}/100")
    m2.metric("Estimated DTI", f"{advanced['dti']:.1f}%")
    m3.metric("Loan / Annual Income", f"{advanced['lti']:.1f}%")

    audit_rows = []
    for name, passed, severity, value, message in advanced["rules"]:
        audit_rows.append({
            "Rule": name,
            "Status": "PASS" if passed else "FAIL",
            "Severity": severity.upper(),
            "Value": value,
            "Explanation": message,
        })
    st.dataframe(audit_rows, use_container_width=True, hide_index=True)

st.caption(
    "The rule engine is an educational banking-style prototype. "
    "Real banks use institution-specific policies, verified bureau data, "
    "fraud controls, affordability assessment, regulatory checks and human governance."
)

# ---------------- MODEL INSIGHTS ----------------
st.markdown(
    '<div class="section-title">Model Insights</div>',
    unsafe_allow_html=True
)

metrics_path = Path("reports/model_metrics.json")

if metrics_path.exists():
    try:
        metrics = pd.read_json(metrics_path, typ="series")

        cols = st.columns(5)

        for col, label, key in zip(
            cols,
            ["Accuracy", "Precision", "Recall", "F1 Score", "ROC-AUC"],
            ["accuracy", "precision", "recall", "f1_score", "roc_auc"],
        ):
            with col:
                st.metric(
                    label,
                    f"{float(metrics[key]) * 100:.2f}%"
                )

    except Exception as error:
        st.warning(f"Metrics could not be loaded: {error}")

else:
    st.info(
        "Model metrics will appear here after `python train.py` finishes."
    )

# Display SHAP explanation if training generated it.
shap_path = Path("reports/shap_summary.png")

if shap_path.exists():
    st.subheader("🔍 Feature Importance / SHAP")
    st.image(str(shap_path), use_container_width=True)

st.caption(
    "Academic portfolio project. The probability shown is a model estimate."
)
