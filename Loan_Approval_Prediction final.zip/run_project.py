"""
Convenience runner for the Loan Approval Prediction project.

Usage:
    python run_project.py

This script performs lightweight checks, trains the model if necessary,
runs the rule-engine tests, and prints the Streamlit command to launch
the application.
"""

from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
MODEL_FILE = ROOT / "models" / "loan_model.joblib"


def run_command(command):
    """Run a Python command and stop if it fails."""
    print("\n>", " ".join(command))
    subprocess.run(command, cwd=ROOT, check=True)


def main():
    """Run the project setup/training checks in a beginner-friendly order."""
    print("=" * 60)
    print("LOAN APPROVAL PREDICTION - PROJECT RUNNER")
    print("=" * 60)

    # Check that the expected data file exists.
    if not (ROOT / "data" / "loan_data.csv").exists():
        raise FileNotFoundError("data/loan_data.csv was not found.")

    # Validate the source files before starting a long training run.
    run_command([sys.executable, "check_project.py"])

    # Train only when a saved model does not already exist.
    if not MODEL_FILE.exists():
        print("\nNo saved model found. Starting training...")
        run_command([sys.executable, "train.py"])
    else:
        print("\nSaved model found. Skipping training.")

    # Run deterministic tests for the banking-style rule engine.
    run_command([sys.executable, "test_rules.py"])

    print("\nProject is ready.")
    print("Start Streamlit with:")
    print("    streamlit run app.py")


if __name__ == "__main__":
    main()
