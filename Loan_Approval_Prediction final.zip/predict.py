# Command-line prediction example.

from utils import predict_applicant


# Example applicant.
# These feature names MUST match the training dataset.
applicant = {
    "Gender": "Male",
    "Married": "Yes",
    "Dependents": "0",
    "Education": "Graduate",
    "Self_Employed": "No",
    "ApplicantIncome": 50000,
    "CoapplicantIncome": 0,
    "LoanAmount": 120,
    "Loan_Amount_Term": 360,
    "Credit_History": 1.0,
    "Property_Area": "Urban",
    "Age": 35,
    "Region": "South",
}

prediction, probability = predict_applicant(applicant)

print(
    "Loan Decision:",
    "APPROVED" if prediction == 1 else "REJECTED"
)

print(f"Approval Probability: {probability * 100:.2f}%")
