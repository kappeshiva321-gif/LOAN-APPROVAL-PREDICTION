# ============================================================
# COMPARE ALL DATASETS
# ============================================================

from pathlib import Path
import pandas as pd

files = [
    Path("data/loan_data.csv"),
    Path("data/external_datasets/dataset1.csv"),
    Path("data/external_datasets/dataset2.csv"),
    Path("data/external_datasets/dataset3.csv"),
]

for path in files:
    print("\n" + "=" * 70)
    print(path)
    print("=" * 70)

    df = pd.read_csv(path)

    print("Rows:", len(df))
    print("Columns:", len(df.columns))
    print("Columns:")
    for column in df.columns:
        print("  -", column)

    target = None
    for candidate in ["Loan_Status", "loan_status"]:
        if candidate in df.columns:
            target = candidate
            break

    if target:
        print("\nTarget distribution:")
        print(df[target].value_counts())
